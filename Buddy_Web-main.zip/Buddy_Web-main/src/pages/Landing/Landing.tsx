
import HeroSection from "../Hero/HeroSection";

export default function Landing() {
  return (
    <div>
      <HeroSection />
    
    </div>
  );
}
